"""
Flask 애플리케이션 팩토리
앱 생성 및 초기화를 담당하는 팩토리 함수
"""

from flask import Flask, jsonify
import os
import config
from services.esp32_communication_service import ESP32CommunicationService
from core.logger_config import setup_logger


def create_app():
    """
    Flask 애플리케이션 생성 및 설정

    팩토리 패턴을 사용하여 앱을 생성합니다.
    - 환경 설정
    - 서비스 초기화
    - 라우트 등록
    - 에러 핸들러 등록

    Returns:
        설정이 완료된 Flask 앱 인스턴스
    """
    # Flask 앱 생성
    app = Flask(__name__)

    # 로거 설정
    setup_logger()

    # ESP32-CAM IP 주소 설정 (환경변수 우선)
    esp32_ip = os.environ.get("ESP32_IP") or config.DEFAULT_ESP32_IP
    esp32_base_url = f"http://{esp32_ip}"

    # 앱 설정 저장
    app.config["ESP32_IP"] = esp32_ip
    app.config["ESP32_BASE_URL"] = esp32_base_url

    # ESP32 통신 서비스 초기화
    esp32_service = ESP32CommunicationService(
        base_url=esp32_base_url, timeout=config.REQUEST_TIMEOUT
    )
    app.config["ESP32_SERVICE"] = esp32_service

    # 블루프린트 등록 (라우트 모듈 연결)
    register_blueprints(app)

    # 에러 핸들러 등록
    register_error_handlers(app)

    return app


def register_blueprints(app):
    """
    블루프린트 등록

    각 라우트 모듈을 앱에 연결합니다.

    Args:
        app: Flask 앱 인스턴스
    """
    from routes.main_routes import main_bp
    from routes.api_routes import api_bp
    from routes.camera_routes import camera_bp

    # 메인 페이지 라우트
    app.register_blueprint(main_bp)

    # API 라우트 (/api/* 경로)
    app.register_blueprint(api_bp)

    # 카메라 라우트
    app.register_blueprint(camera_bp)


def register_error_handlers(app):
    """
    에러 핸들러 등록

    HTTP 에러 발생 시 처리 로직을 정의합니다.

    Args:
        app: Flask 앱 인스턴스
    """

    @app.errorhandler(404)
    def not_found(error):
        """404 에러 핸들러"""
        return jsonify({"error": "페이지를 찾을 수 없습니다"}), 404

    @app.errorhandler(500)
    def internal_error(error):
        """500 에러 핸들러"""
        return jsonify({"error": "서버 내부 오류"}), 500
